﻿using System.Runtime.CompilerServices;

namespace Task1.Models
{
    public class Employees
    {
        public int Id { get; set; }
        public String Fullname { get; set; }
        public string Department { get; set; }
    }
}
